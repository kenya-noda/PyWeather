#!/usr/bin/env python

#
# Precipitation conversions
#
# -Christopher Blunck
#

import sys

__author__ = 'Christopher Blunck'
__email__ = 'chris@wxnet.org'
__revision__ = '$Revision: 1.6 $'

__doc__ = '''
precipitation related conversions
'''

__usage__ = ''


